# ------ Command++ ver 0.1 ------

import os
import time
import subprocess
import platform
import shutil
import webbrowser
from datetime import datetime
from pathlib import Path

import yaml
from rich.console import Console
from rich.progress import Progress
from rich.panel import Panel
from rich.table import Table

console = Console()

# ================= CONSTANTS =================
VERSION = "0.1"
BASE_DIR = Path(__file__).parent

HISTORY_FILE  = BASE_DIR / "history.yml"
SNIPPETS_FILE = BASE_DIR / "snippets.yml"

# ================= UTIL =================
def ensure_file(path, default):
    if not path.exists():
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(default, f)

def load_yaml(path):
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def save_yaml(path, data):
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f)

# ================= UI =================
def loading_screen():
    console.print(f"[bold cyan]------ Command++ ver {VERSION} ------[/bold cyan]\n")
    for step in ("Loading core", "Preparing shell"):
        with Progress(transient=True) as p:
            t = p.add_task(step, total=100)
            for _ in range(10):
                time.sleep(0.05)
                p.update(t, advance=10)
    console.print("[green]✔ Ready[/green]\n")

# ================= HISTORY =================
def save_history(cmd, output):
    data = load_yaml(HISTORY_FILE)
    key = cmd.split()[0]
    data.setdefault(key, []).append({
        "command": cmd,
        "output": output.strip(),
        "time": datetime.utcnow().isoformat() + "Z"
    })
    save_yaml(HISTORY_FILE, data)

def show_history():
    data = load_yaml(HISTORY_FILE)
    if not data:
        console.print("[yellow]No history yet[/yellow]")
        return

    table = Table("Tool", "Command", "Output", "Time")
    for tool, entries in data.items():
        for e in entries[-10:]:
            table.add_row(tool, e["command"], e["output"][:40], e["time"])
    console.print(Panel(table, title="📜 History"))

def clear_history(force=False):
    if not HISTORY_FILE.exists():
        console.print("[yellow]History already empty[/yellow]")
        return
    if not force:
        if input("Type YES to confirm >>> ") != "YES":
            console.print("[cyan]Cancelled[/cyan]")
            return
    HISTORY_FILE.unlink()
    console.print("[green]✔ History cleared[/green]")

# ================= SNIPPETS =================
def snippet_add(name, cmd):
    s = load_yaml(SNIPPETS_FILE)
    s[name] = cmd
    save_yaml(SNIPPETS_FILE, s)
    console.print(f"[green]✔ Snippet '{name}' saved[/green]")

def snippet_list():
    s = load_yaml(SNIPPETS_FILE)
    if not s:
        console.print("[yellow]No snippets[/yellow]")
        return
    for k, v in s.items():
        console.print(f"[cyan]{k}[/cyan] → {v}")

def snippet_run(name):
    s = load_yaml(SNIPPETS_FILE)
    if name not in s:
        console.print("[yellow]Snippet not found[/yellow]")
        return
    execute(s[name])

# ================= SYSTEM =================
def show_system_info():
    console.print(Panel.fit("🖥 System Info", style="bold cyan"))
    console.print(f"OS: {platform.system()} {platform.release()}")
    console.print(f"Python: {platform.python_version()}")
    console.print(f"Machine: {platform.machine()}")
    console.print(f"Terminal: {shutil.get_terminal_size()}")

# ================= FETCH =================
def is_installed(app):
    exe_map = {
        "vscode": "code",
        "code": "code",
        "python": "python",
        "git": "git",
        "node": "node"
    }
    exe = exe_map.get(app.lower(), app)
    return shutil.which(exe) is not None

def fetch_app():
    console.print("[cyan]Enter app name >>>[/cyan] ", end="")
    app = input().strip()
    if not app:
        return

    if is_installed(app):
        console.print(f"[green]✔ {app} is already downloaded[/green]")
        return

    console.print("[yellow]Opening download page...[/yellow]")
    webbrowser.open(f"https://www.google.com/search?q={app}+official+download")

# ================= HELP =================
def show_help():
    rows = [
        ("cmdpp help / commands", "Show this help"),
        ("cmdpp fetch", "Interactive app download"),
        ("cmdpp fsys", "System information"),
        ("cmdpp history show", "Show command history"),
        ("cmdpp history clear --yes", "Clear history"),
        ("cmdpp snippet add <n> <cmd>", "Add snippet"),
        ("cmdpp snippet run <n>", "Run snippet"),
        ("cmdpp snippet list", "List snippets"),
        (":s", "Shortcut for history"),
        ("!name", "Run snippet")
    ]
    table = Table("Command", "Description")
    for c, d in rows:
        table.add_row(c, d)
    console.print(Panel(table, title="Command++ Commands"))

# ================= INTERNAL DISPATCH =================
def handle_cmdpp(parts):
    # parts[0] == "cmdpp" always

    if len(parts) == 1:
        show_help()
        return True

    if parts[1] in ("help", "commands"):
        show_help()
        return True

    if parts[1:] == ["fetch"]:
        fetch_app()
        return True

    if parts[1:] == ["fsys"]:
        show_system_info()
        return True

    if parts[1:] == ["history", "show"]:
        show_history()
        return True

    if parts[1:] == ["history", "clear"]:
        clear_history(False)
        return True

    if parts[1:] == ["history", "clear", "--yes"]:
        clear_history(True)
        return True

    if parts[1:3] == ["snippet", "add"] and len(parts) >= 5:
        snippet_add(parts[3], " ".join(parts[4:]))
        return True

    if parts[1:3] == ["snippet", "run"] and len(parts) == 4:
        snippet_run(parts[3])
        return True

    if parts[1:] == ["snippet", "list"]:
        snippet_list()
        return True

    console.print("[red]Unknown cmdpp command. Try 'cmdpp help'[/red]")
    return True  # IMPORTANT: never fall through

# ================= EXECUTION =================
def execute(cmd):
    # snippet shorthand
    if cmd.startswith("!"):
        snippet_run(cmd[1:])
        return

    parts = cmd.split()

    # 🔒 HARD GUARANTEE: cmdpp NEVER reaches shell
    if parts and parts[0] == "cmdpp":
        handle_cmdpp(parts)
        return

    # history shortcut
    if cmd in (":s", ":saved"):
        show_history()
        return

    # shell fallback
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if p.returncode == 0:
            if p.stdout.strip():
                console.print(p.stdout.strip())
            save_history(cmd, p.stdout)
        else:
            console.print("[red]Command failed[/red]")
            if p.stderr:
                console.print(p.stderr.strip())
    except Exception as e:
        console.print(f"[red]{e}[/red]")

# ================= MAIN =================
def main():
    ensure_file(HISTORY_FILE, {})
    ensure_file(SNIPPETS_FILE, {})

    loading_screen()

    while True:
        try:
            raw = input("Command++ > ").strip()
            if raw in ("exit", "quit"):
                break
            if raw:
                execute(raw)
        except KeyboardInterrupt:
            console.print("\n[cyan]Interrupted[/cyan]")

if __name__ == "__main__":
    main()
